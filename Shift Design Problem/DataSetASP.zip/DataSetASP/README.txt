Answer Set Programming for the Shift Design Problem - Instances:
================================================================

The content of this archive is based on existing problem instances 
for the Shift Design Problem which can be downloaded under the 
following links:

http://www.dbai.tuwien.ac.at/proj/Rota/DataSet1.zip
http://www.dbai.tuwien.ac.at/proj/Rota/DataSet2.zip
http://www.dbai.tuwien.ac.at/proj/Rota/DataSet3.zip
http://www.dbai.tuwien.ac.at/proj/Rota/DataSet4.zip

For a detailed explanation of the instances and corresponding 
approximations for their optimal fitness value, please see the 
official homepage of the benchmarks for project "Rota" [1] or 
the Master's Thesis by Michael Abseher [2].

For further informations, contact the corresponding author

abseher (at) dbai (dot) tuwien (dot) ac (dot) at!

----------------------------------------------------------------

[1]: http://www.dbai.tuwien.ac.at/proj/Rota/benchmarks.html
[2]: Abseher Michael. Solving Shift Design Problems with
     Answer Set Programming. Master's Thesis, Technische 
     Universit�t Wien, 2013
