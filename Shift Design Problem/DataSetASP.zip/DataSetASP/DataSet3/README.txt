Answer Set Programming for the Shift Design Problem - DataSet3:
===============================================================

The content of this directory is based on existing instances 
for the Shift Design Problem which can be downloaded under 
the following link:

http://www.dbai.tuwien.ac.at/proj/Rota/DataSet3.zip

For a detailed explanation of the instances and corresponding 
approximations for their optimal fitness value, please see the 
official homepage of the benchmarks for project "Rota" [1] or 
the Master's Thesis by Michael Abseher [2].

For further informations, contact the corresponding author

abseher (at) dbai (dot) tuwien (dot) ac (dot) at!

----------------------------------------------------------------

We note that, compared to the project "Rota" [1] in which the 
instances have been introduced, the dataset at hand sometimes
contains multiple versions of each variants, which differ in
the granularity of the timeslots (15 minutes, 30 minutes or
60 minutes). 

This is primarily to test the solvers capability of dealing with 
an increased number of timeslots. For benchmarking purposes, 
always the coarsest granularity should be used because only this 
instance is identical to the one used in the original project.

This means, if the directory for the instance, e.g. RandomExample1, 
contains the files 15m.lp, 30m.lp and 60m.lp, the program 60m.lp
is identical to Instance 1 in the original dataset used in "Rota".

----------------------------------------------------------------

[1]: http://www.dbai.tuwien.ac.at/proj/Rota/benchmarks.html
[2]: Abseher Michael. Solving Shift Design Problems with
     Answer Set Programming. Master's Thesis, Technische 
     Universit�t Wien, 2013
